<?php
// Hosting-only credentials. This file is intentionally excluded from Git.
if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    http_response_code(404);
    exit;
}
return [
    'host' => 'sql102.infinityfree.com',
    'user' => 'if0_40553548',
    'pass' => '0975372230Soai',
    'db' => 'if0_40553548_tananh',
];
